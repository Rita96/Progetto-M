
package client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Classe LineClient: si occupa di effettuare la connessione con il server 
 * dell'applicazione principale, passa da remoto i parametri di connessione e i 
 * parametri richiesti per la manipolazione dei dati inerenti la gestione degli utenze
 * di tipo arbitro presenti all'interno del database, permettendo di aggiungere e 
 * rimuovere tali utenze.
 *  
 * @author giadamarconi
 */


public class LineClient 
{  
    public static void main(String[] args) throws IOException 
    {
        String ip = "127.0.0.1";
        int port = 4020;
        Socket socket = new Socket(ip, port); 
        System.out.println("Connessione stabilita correttamente.");
        Scanner socketIn = new Scanner(socket.getInputStream()); 
        PrintWriter socketOut = new PrintWriter(socket.getOutputStream()); 
        Scanner stdin = new Scanner(System.in);
        try 
        {
            while (true) 
            {
                while(socketIn.hasNextLine() == false);
                String socketLine = socketIn.nextLine(); 
                System.out.println(socketLine);
                String inputLine = stdin.nextLine(); 
                socketOut.println(inputLine); 
                socketOut.flush();
                socketLine = socketIn.nextLine(); 
                System.out.println(socketLine);
            }
        } 
        catch(NoSuchElementException e)
        {
            System.out.println("Connessione chiusa per Eccezione."); 
        } 
        finally {
            socketIn.close();
            socketOut.close();
            socket.close();
        }    
    }
}